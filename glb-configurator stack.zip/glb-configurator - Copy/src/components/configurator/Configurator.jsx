import { useConfigStore } from '../../store/useConfigStore'
import React from 'react'

export function Configurator() {
    const {
        objects,
        addObject,
        selectedId,
        removeObject,
        duplicateObject,
        stackObject,
        updateObject,
        triggerExport,
        setModelUrl,
        startBatch,
        isBatching,
        exportScope,
        setExportScope
    } = useConfigStore()

    const selectedObject = objects.find(o => o.id === selectedId)

    // Batch UI State
    const [batchStart, setBatchStart] = React.useState(1.0)
    const [batchEnd, setBatchEnd] = React.useState(2.0)
    const [batchStep, setBatchStep] = React.useState(0.2)
    const [batchAxis, setBatchAxis] = React.useState('all')

    const handleFileUpload = (event) => {
        const file = event.target.files[0]
        if (file) {
            const url = URL.createObjectURL(file)
            // For scene builder, uploading adds a NEW object
            addObject(url)
        }
    }

    const handleTransformChange = (axis, value, type) => {
        if (!selectedObject) return
        const current = selectedObject[type] // [x, y, z]
        const updated = [...current]
        updated[axis] = parseFloat(value)
        updateObject(selectedId, { [type]: updated })
    }

    return (
        <div style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Scene Builder</h2>

            {/* Export Section */}
            <div style={{ marginBottom: '1rem' }}>
                <div style={{ marginBottom: '10px' }}>
                    <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '5px' }}>Export Scope</label>
                    <select
                        value={exportScope}
                        onChange={(e) => setExportScope(e.target.value)}
                        style={{ width: '100%', padding: '5px', marginBottom: '10px' }}
                    >
                        <option value="scene">Entire Scene</option>
                        <option value="selected">Selected Object Only</option>
                    </select>
                </div>

                <button
                    onClick={triggerExport}
                    style={{
                        width: '100%',
                        padding: '10px',
                        background: '#007bff',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: 500,
                    }}
                >
                    Export {exportScope === 'scene' ? 'Scene' : 'Selected'} (.glb)
                </button>
            </div>

            {/* Batch Export UI */}
            {selectedObject && (
                <div style={{ marginBottom: '1rem', padding: '10px', border: '1px solid #ddd', borderRadius: '4px', background: '#f9f9f9' }}>
                    <h4 style={{ margin: '0 0 10px 0' }}>Auto-Scale Export</h4>
                    <div style={{ display: 'flex', gap: '5px', marginBottom: '10px' }}>
                        <div>
                            <label style={{ fontSize: '0.8rem' }}>Start</label>
                            <input
                                type="number"
                                step="0.1"
                                value={batchStart}
                                onChange={(e) => setBatchStart(parseFloat(e.target.value))}
                                style={{ width: '100%' }}
                            />
                        </div>
                        <div>
                            <label style={{ fontSize: '0.8rem' }}>End</label>
                            <input
                                type="number"
                                step="0.1"
                                value={batchEnd}
                                onChange={(e) => setBatchEnd(parseFloat(e.target.value))}
                                style={{ width: '100%' }}
                            />
                        </div>
                        <div>
                            <label style={{ fontSize: '0.8rem' }}>Step</label>
                            <input
                                type="number"
                                step="0.1"
                                value={batchStep}
                                onChange={(e) => setBatchStep(parseFloat(e.target.value))}
                                style={{ width: '100%' }}
                            />
                        </div>
                    </div>

                    <div style={{ marginBottom: '10px' }}>
                        <label style={{ fontSize: '0.8rem', display: 'block', marginBottom: '5px' }}>Axis</label>
                        <select
                            value={batchAxis}
                            onChange={(e) => setBatchAxis(e.target.value)}
                            style={{ width: '100%', padding: '5px' }}
                        >
                            <option value="all">All (Uniform)</option>
                            <option value="x">X (Length)</option>
                            <option value="y">Y (Height)</option>
                            <option value="z">Z (Width)</option>
                        </select>
                    </div>

                    <button
                        onClick={() => startBatch(selectedId, batchStart, batchEnd, batchStep, batchAxis)}
                        disabled={isBatching}
                        style={{
                            width: '100%',
                            padding: '8px',
                            background: isBatching ? '#ccc' : '#e91e63',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: isBatching ? 'not-allowed' : 'pointer'
                        }}
                    >
                        {isBatching ? 'Processing...' : 'Generate Variants'}
                    </button>
                    {isBatching && <p style={{ fontSize: '0.8rem', color: '#666', textAlign: 'center', margin: '5px 0 0 0' }}>Don't close window</p>}
                </div>
            )}

            {/* Add Object */}
            <div style={{ paddingBottom: '1rem', borderBottom: '1px solid #eee' }}>
                <label className="button-upload" style={{
                    display: 'block',
                    padding: '10px',
                    background: '#213547',
                    color: 'white',
                    textAlign: 'center',
                    cursor: 'pointer',
                    borderRadius: '4px'
                }}>
                    + Add Model
                    <input
                        type="file"
                        accept=".glb,.gltf"
                        onChange={handleFileUpload}
                        style={{ display: 'none' }}
                    />
                </label>
                <p style={{ fontSize: '0.8rem', color: '#666', marginTop: '0.5rem' }}>
                    {objects.length} objects in scene
                </p>
            </div>

            {selectedObject ? (
                <>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h3 style={{ margin: 0 }}>Selected Object</h3>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button onClick={() => stackObject(selectedId)} title="Stack on Top" style={{ background: '#4CAF50', color: 'white', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}>Stack</button>
                            <button onClick={() => duplicateObject(selectedId)} title="Duplicate">Copy</button>
                            <button onClick={() => removeObject(selectedId)} title="Delete" style={{ color: 'red' }}>Del</button>
                        </div>
                    </div>

                    {/* Position */}
                    <div>
                        <label style={{ fontWeight: 500 }}>Position (X, Y, Z)</label>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            {[0, 1, 2].map(axis => (
                                <input
                                    key={`pos-${axis}`}
                                    type="number"
                                    step="0.1"
                                    value={selectedObject.position[axis].toFixed(2)}
                                    onChange={(e) => handleTransformChange(axis, e.target.value, 'position')}
                                    style={{ width: '33%' }}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Scale */}
                    <div>
                        <label style={{ fontWeight: 500 }}>Scale (L, W, H)</label>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            {[0, 1, 2].map(axis => (
                                <input
                                    key={`scl-${axis}`}
                                    type="number"
                                    step="0.1"
                                    value={selectedObject.scale[axis].toFixed(2)}
                                    onChange={(e) => handleTransformChange(axis, e.target.value, 'scale')}
                                    style={{ width: '33%' }}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Rotation */}
                    <div>
                        <label style={{ fontWeight: 500 }}>Rotation (X, Y, Z)</label>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            {[0, 1, 2].map(axis => (
                                <input
                                    key={`rot-${axis}`}
                                    type="number"
                                    step="0.1"
                                    value={selectedObject.rotation[axis].toFixed(2)}
                                    onChange={(e) => handleTransformChange(axis, e.target.value, 'rotation')}
                                    style={{ width: '33%' }}
                                />
                            ))}
                        </div>
                    </div>
                </>
            ) : (
                <div style={{ textAlign: 'center', color: '#888', marginTop: '2rem' }}>
                    Select an object to edit properties
                </div>
            )}
        </div>
    )
}
