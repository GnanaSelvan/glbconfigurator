import React, { useMemo, useEffect } from 'react'
import { useGLTF } from '@react-three/drei'
import { useConfigStore } from '../../store/useConfigStore'
import * as THREE from 'three'

export function SceneObject({ id, url, position, rotation, scale, materials }) {
    // Use suspense false to handle loading gracefully if needed, though useGLTF suspends by default
    const { scene } = useGLTF(url)
    const { selectObject, updateObject } = useConfigStore()

    // Clone scene using useMemo so it's ready for render and stable
    const clonedScene = useMemo(() => {
        const clone = scene.clone()
        return clone
    }, [scene])

    // Calculate dimensions on load
    useEffect(() => {
        if (clonedScene) {
            const box = new THREE.Box3().setFromObject(clonedScene)
            const size = new THREE.Vector3()
            box.getSize(size)

            updateObject(id, { dimensions: [size.x, size.y, size.z] })
        }
    }, [clonedScene, id]) // Removed updateObject from dependency array

    // Apply materials
    useEffect(() => {
        if (clonedScene) {
            clonedScene.traverse((child) => {
                if (child.isMesh && child.material) {
                    const matName = child.material.name
                    const matConfig = materials[matName]

                    if (!child.userData.originalMaterial) {
                        child.userData.originalMaterial = child.material.clone()
                        child.material = child.userData.originalMaterial
                    }

                    if (matConfig?.color) {
                        child.material.color.set(matConfig.color)
                    }
                }
            })
        }
    }, [clonedScene, materials])

    return (
        <primitive
            object={clonedScene}
            position={position}
            rotation={rotation}
            scale={scale}
            onClick={(e) => {
                e.stopPropagation()
                selectObject(id)
            }}
            userData={{ id }}
        />
    )
}
