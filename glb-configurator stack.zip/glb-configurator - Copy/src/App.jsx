import { Layout } from './components/common/Layout'
import { Configurator } from './components/configurator/Configurator'
import { Viewer3D } from './components/viewer/Viewer3D'
import { MultiView } from './components/viewer/MultiView'
import { useState } from 'react'

function App() {
  const [activeTab, setActiveTab] = useState('3d')

  return (
    <Layout
      leftPanel={<Configurator />}
      rightPanel={
        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column' }}>
          {/* Tab Switcher */}
          <div style={{ display: 'flex', background: '#e0e0e0', borderBottom: '1px solid #ccc' }}>
            <button
              onClick={() => setActiveTab('3d')}
              style={{
                flex: 1,
                padding: '10px',
                border: 'none',
                background: activeTab === '3d' ? '#fff' : 'transparent',
                fontWeight: activeTab === '3d' ? 'bold' : 'normal',
                cursor: 'pointer'
              }}
            >
              3D View
            </button>
            <button
              onClick={() => setActiveTab('2d')}
              style={{
                flex: 1,
                padding: '10px',
                border: 'none',
                background: activeTab === '2d' ? '#fff' : 'transparent',
                fontWeight: activeTab === '2d' ? 'bold' : 'normal',
                cursor: 'pointer'
              }}
            >
              2D Views
            </button>
          </div>

          {/* Content Area */}
          <div style={{ flex: 1, position: 'relative' }}>
            {activeTab === '3d' ? <Viewer3D /> : <MultiView />}
          </div>
        </div>
      }
    />
  )
}

export default App
