import { create } from 'zustand'
import { v4 as uuidv4 } from 'uuid'

export const useConfigStore = create((set, get) => ({
  objects: [],
  selectedId: null,
  exportRequested: 0,

  // Batch State
  batchQueue: [],
  isBatching: false,

  // Actions
  triggerExport: () => set({ exportRequested: Date.now() }),

  exportScope: 'scene', // 'scene' | 'selected'
  setExportScope: (scope) => set({ exportScope: scope }),

  exportFinished: () => {
    const { isBatching, processNextBatchItem } = get()
    if (isBatching) {
      // Add small delay to ensure UI/Browser catches up
      setTimeout(() => {
        processNextBatchItem()
      }, 500)
    }
  },

  startBatch: (id, start, end, step, axis = 'all') => {
    const queue = []
    // Fix floating point issues
    const precision = step.toString().split('.')[1]?.length || 0

    for (let s = start; s <= end + 0.0001; s += step) { // + epsilon
      queue.push({ id, scale: parseFloat(s.toFixed(precision)), axis })
    }

    set({ batchQueue: queue, isBatching: true })
    get().processNextBatchItem()
  },

  processNextBatchItem: () => {
    const { batchQueue, updateObject, triggerExport } = get()

    if (batchQueue.length === 0) {
      set({ isBatching: false })
      return
    }

    const [nextItem, ...remaining] = batchQueue

    // Update store state
    set({ batchQueue: remaining })

    // Apply scale
    const obj = get().objects.find(o => o.id === nextItem.id)
    if (obj) {
      let newScale = [...obj.scale]
      const val = nextItem.scale

      if (nextItem.axis === 'all') {
        newScale = [val, val, val]
      } else if (nextItem.axis === 'x') {
        newScale[0] = val
      } else if (nextItem.axis === 'y') {
        newScale[1] = val
      } else if (nextItem.axis === 'z') {
        newScale[2] = val
      }

      updateObject(nextItem.id, { scale: newScale })

      // Trigger export
      // Slight delay to allow React to render the new scale
      setTimeout(() => {
        triggerExport()
      }, 100)
    } else {
      // Object gone? stop or skip
      set({ isBatching: false })
    }
  },

  addObject: (url) => set((state) => {
    const newId = uuidv4()
    const newObject = {
      id: newId,
      url,
      position: [0, 0, 0],
      rotation: [0, 0, 0],
      scale: [1, 1, 1],
      dimensions: [1, 1, 1], // Default until calculated
      materials: {}
    }
    return {
      objects: [...state.objects, newObject],
      selectedId: newId
    }
  }),

  selectObject: (id) => set({ selectedId: id }),

  updateObject: (id, changes) => set((state) => ({
    objects: state.objects.map(obj =>
      obj.id === id ? { ...obj, ...changes } : obj
    )
  })),

  removeObject: (id) => set((state) => ({
    objects: state.objects.filter(obj => obj.id !== id),
    selectedId: state.selectedId === id ? null : state.selectedId
  })),

  duplicateObject: (id) => set((state) => {
    const objToDuplicate = state.objects.find(o => o.id === id)
    if (!objToDuplicate) return {}

    const newId = uuidv4()
    const newObject = {
      ...objToDuplicate,
      id: newId,
      position: [
        objToDuplicate.position[0] + 0.5,
        objToDuplicate.position[1],
        objToDuplicate.position[2] + 0.5
      ]
    }

    return {
      objects: [...state.objects, newObject],
      selectedId: newId
    }
  }),

  stackObject: (id) => set((state) => {
    const obj = state.objects.find(o => o.id === id)
    if (!obj) return {}

    const newId = uuidv4()
    // Calculate height based on dimensions and scale
    const height = obj.dimensions[1] * obj.scale[1]

    const newObject = {
      ...obj,
      id: newId,
      position: [
        obj.position[0],
        obj.position[1] + height, // Place exactly on top
        obj.position[2]
      ]
    }

    return {
      objects: [...state.objects, newObject],
      selectedId: newId
    }
  }),

  updateSelectedMaterial: (materialName, color) => {
    const { selectedId, objects, updateObject } = get()
    if (!selectedId) return

    const obj = objects.find(o => o.id === selectedId)
    if (!obj) return

    const updatedMaterials = {
      ...obj.materials,
      [materialName]: { ...obj.materials[materialName], color }
    }

    updateObject(selectedId, { materials: updatedMaterials })
  }
}))
