import React from 'react'
import { Canvas } from '@react-three/fiber'
import { OrthographicCamera, TransformControls, Grid, OrbitControls } from '@react-three/drei'
import { useConfigStore } from '../../store/useConfigStore'
import { SceneObject } from './SceneObject'

function ViewPort({ title, cameraProps, axisLock, children }) {
    return (
        <div style={{ position: 'relative', width: '100%', height: '100%', border: '1px solid #ccc', background: '#f0f0f0' }}>
            <div style={{ position: 'absolute', top: 5, left: 5, zIndex: 10, background: 'rgba(255,255,255,0.8)', padding: '2px 5px', fontSize: '12px', fontWeight: 'bold' }}>
                {title}
            </div>
            <Canvas>
                <ambientLight intensity={0.5} />
                <directionalLight position={[10, 10, 5]} intensity={1} />
                <OrthographicCamera
                    makeDefault
                    position={cameraProps.position}
                    rotation={cameraProps.rotation || [0, 0, 0]}
                    zoom={cameraProps.zoom || 40} // Increased zoom
                    near={-100}
                    far={200} // Increased far plane
                    up={cameraProps.up}
                />
                <OrbitControls
                    enableRotate={false}
                    enableZoom={true}
                    enablePan={true}
                    target={[0, 0, 0]} // Center camera
                />
                <Grid args={[20, 20]} cellSize={1} cellThickness={1} cellColor="#6f6f6f" sectionSize={5} sectionThickness={1.5} sectionColor="#9d4b4b" fadeDistance={50} infiniteGrid />
                {children}
            </Canvas>
        </div>
    )
}

function SceneContent({ axisLock }) {
    const { objects, selectedId, updateObject } = useConfigStore()

    return (
        <group name="scene-content">
            {objects.map((obj) => (
                <group key={obj.id}>
                    {selectedId === obj.id ? (
                        <TransformControls
                            object={undefined}
                            mode={axisLock.mode || "translate"}
                            showX={axisLock.showX}
                            showY={axisLock.showY}
                            showZ={axisLock.showZ}
                            size={0.6}
                            onObjectChange={(e) => {
                                if (e && e.target && e.target.object) {
                                    const o = e.target.object
                                    updateObject(obj.id, {
                                        position: [o.position.x, o.position.y, o.position.z],
                                        rotation: [o.rotation.x, o.rotation.y, o.rotation.z],
                                        scale: [o.scale.x, o.scale.y, o.scale.z]
                                    })
                                }
                            }}
                        >
                            <SceneObject {...obj} />
                        </TransformControls>
                    ) : (
                        <SceneObject {...obj} />
                    )}
                </group>
            ))}
        </group>
    )
}

export function MultiView() {
    return (
        <div style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gridTemplateRows: '1fr 1fr', gap: '2px', background: '#ccc' }}>
            {/* Top View (X/Z Plane) */}
            <ViewPort
                title="TOP (X/Z)"
                cameraProps={{
                    position: [0, 50, 0],
                    rotation: [-Math.PI / 2, 0, 0],
                    up: [0, 0, -1]
                }}
                axisLock={{ showY: false }}
            >
                <SceneContent axisLock={{ showY: false, showX: true, showZ: true }} />
            </ViewPort>

            {/* Front View (X/Y Plane) */}
            <ViewPort
                title="FRONT (X/Y)"
                cameraProps={{ position: [0, 0, 50], up: [0, 1, 0] }}
                axisLock={{ showZ: false }}
            >
                <SceneContent axisLock={{ showZ: false, showX: true, showY: true }} />
            </ViewPort>

            {/* Side View (Z/Y Plane) */}
            <ViewPort
                title="SIDE (Z/Y)"
                cameraProps={{
                    position: [50, 0, 0],
                    rotation: [0, Math.PI / 2, 0],
                    up: [0, 1, 0]
                }}
                axisLock={{ showX: false }}
            >
                <SceneContent axisLock={{ showX: false, showY: true, showZ: true }} />
            </ViewPort>

            {/* Placeholder or Legend */}
            <div style={{ background: '#fff', padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                <h3>2D Views</h3>
                <p>Drag objects to move.</p>
                <p>Changes reflect in 3D.</p>
            </div>
        </div>
    )
}
