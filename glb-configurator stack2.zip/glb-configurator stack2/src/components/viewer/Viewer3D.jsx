import { useRef, useEffect, useMemo } from 'react'
import { Canvas, useThree } from '@react-three/fiber'
import { OrbitControls, Environment, useGLTF, TransformControls } from '@react-three/drei'
import { useConfigStore } from '../../store/useConfigStore'
import { GLTFExporter } from 'three-stdlib'
import { SceneObject } from './SceneObject'
import * as THREE from 'three'

function SceneExporter() {
    const { scene } = useThree()
    const { exportRequested, exportFinished, exportScope, selectedId } = useConfigStore()

    useEffect(() => {
        if (exportRequested === 0) return

        const exporter = new GLTFExporter()

        // Collect all valid user objects from the scene
        const userObjects = []
        scene.traverse((obj) => {
            if (obj.userData && obj.userData.id) {
                userObjects.push(obj)
            }
        })

        let exportTarget = []
        if (exportScope === 'selected' && selectedId) {
            exportTarget = userObjects.filter(obj => obj.userData.id === selectedId)
        } else {
            // Export all user objects
            exportTarget = userObjects
        }

        // Options: binary = true for .glb
        exporter.parse(
            exportTarget,
            (result) => {
                if (result instanceof ArrayBuffer) {
                    saveArrayBuffer(result, `scene_${Date.now()}.glb`)
                } else {
                    const output = JSON.stringify(result, null, 2)
                    saveString(output, `scene_${Date.now()}.gltf`)
                }
                exportFinished() // Signal completion
            },
            (error) => {
                console.error('An error happened during export:', error)
                exportFinished() // Proceed even on error to not block queue
            },
            { binary: true }
        )
    }, [exportRequested, scene, exportFinished])

    return null
}

function saveArrayBuffer(buffer, filename) {
    save(new Blob([buffer], { type: 'application/octet-stream' }), filename)
}

function saveString(text, filename) {
    save(new Blob([text], { type: 'text/plain' }), filename)
}

function save(blob, filename) {
    const link = document.createElement('a')
    link.style.display = 'none'
    document.body.appendChild(link)
    link.href = URL.createObjectURL(blob)
    link.download = filename
    link.click()
    document.body.removeChild(link)
}

function SceneContent() {
    const { objects, selectedId, updateObject } = useConfigStore()

    return (
        <group name="scene-content">
            {objects.map((obj) => (
                <group key={obj.id}>
                    {selectedId === obj.id ? (
                        <TransformControls
                            object={undefined}
                            mode="translate"
                            onObjectChange={(e) => {
                                if (e && e.target && e.target.object) {
                                    const o = e.target.object
                                    updateObject(obj.id, {
                                        position: [o.position.x, o.position.y, o.position.z],
                                        rotation: [o.rotation.x, o.rotation.y, o.rotation.z],
                                        scale: [o.scale.x, o.scale.y, o.scale.z]
                                    })
                                }
                            }}
                        >
                            <SceneObject {...obj} />
                        </TransformControls>
                    ) : (
                        <SceneObject {...obj} />
                    )}
                </group>
            ))}
        </group>
    )
}

export function Viewer3D() {
    return (
        <div style={{ width: '100%', height: '100%' }}>
            <Canvas shadows camera={{ position: [5, 5, 5], fov: 45 }}>
                <ambientLight intensity={0.5} />
                <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
                <Environment preset="city" />

                <SceneContent />
                <SceneExporter />

                <OrbitControls makeDefault />
                <gridHelper args={[20, 20]} />
                <axesHelper args={[5]} />
            </Canvas>
        </div>
    )
}
