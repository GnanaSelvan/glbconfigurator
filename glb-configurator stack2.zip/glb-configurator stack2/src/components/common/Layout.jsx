export function Layout({ leftPanel, rightPanel }) {
    return (
        <div style={{ display: 'flex', width: '100vw', height: '100vh', overflow: 'hidden' }}>
            <div style={{ width: '30%', minWidth: '300px', borderRight: '1px solid #ddd', overflowY: 'auto', background: '#fff', zIndex: 10 }}>
                {leftPanel}
            </div>
            <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
                {rightPanel}
            </div>
        </div>
    )
}
